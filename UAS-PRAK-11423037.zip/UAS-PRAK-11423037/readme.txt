Name Of DataBase : db_booking_lapangan
localhost : 3307
username  : root
password  :

Username & Password
* Admin
- Username : jawir
- Password : pemilik 	

* User
- Username : yonatan
- Password : silitonga

* Pengelola
- Username : risk
- Password : pemilik


ENV file ada di
.env.example hapus ".example" nya
