



<?php $__env->startSection('title', 'Keranjang Belanja >'); ?>
<?php $__env->startSection('sub_title', 'Checkout'); ?>
<?php $__env->startSection('dynamic_nav_links'); ?>

    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Checkout</h1>
        <div class="row">
            <div class="col-md-8">
                <!-- Form checkout -->
                
                <form action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <!-- Isi form checkout disini -->
                    <div class="mb-3">
                        <label for="alamat">Alamat Pengiriman</label>
                        <textarea class="form-control" id="alamat" name="alamat" rows="3" placeholder="Masukkan alamat pengiriman Anda"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
            <div class="col-md-4">
                <!-- Isi bagian kanan dengan ringkasan total pembelian -->
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Ringkasan Pembelian</h5>                        
                        <!-- Hitung total produk -->
                        <?php
                            $total_produk = 0;
                            foreach ($transaksi_olahraga as $transaksi) {
                                $total_produk += $transaksi->jumlah;
                            }
                        ?>
                        <p class="card-text">Total Produk: <?php echo e($total_produk); ?></p>
                        
                        <?php
                            $total_harga = 0;
                            foreach ($transaksi_olahraga as $transaksi) {
                                $total_harga += $transaksi->jumlah * $transaksi->product->harga_produkolahraga;
                            }
                        ?>
                        <p class="card-text">Total Harga: Rp <?php echo e(number_format($total_harga, 0, ',', '.')); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\UAS-PRAK-11423005_01\UAS-PRAK-11423005\resources\views/checkout/checkout_user.blade.php ENDPATH**/ ?>