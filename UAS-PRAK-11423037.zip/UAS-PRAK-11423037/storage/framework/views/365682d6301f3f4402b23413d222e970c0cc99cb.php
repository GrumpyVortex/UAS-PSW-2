

<?php $__env->startSection('title', 'Pengelola Details'); ?>

<?php $__env->startSection('contents'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <h1>Player List</h1>

        <!-- Add manager Button -->
        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addPlayerModal">
            Add Player
        </button>

        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Last Login</th>
                    <th>Jenis Pelanggan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($player->id_pengguna); ?></td>
                        <td><?php echo e($player->username_pengguna); ?></td>
                        <td><?php echo e($player->last_login); ?></td>

                        <td><?php echo e(optional($player->pelanggan)->jenis_pelanggan ?? 'Biasa'); ?></td>
                        <td>
                            <button type="button" class="btn btn-success m-2" data-bs-toggle="modal"
                                data-bs-target="#editModal<?php echo e($player->id_pengguna); ?>">
                                Ganti Status Pelanggan
                            </button>
                            
                            <form action="<?php echo e(route('pengguna.destroy', $player->id_pengguna)); ?>" method="POST"
                                class="d-inline" onsubmit="return confirm('Are you sure you want to delete this player?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>


    <!-- Edit Modal -->
    <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="editModal<?php echo e($item->id_pengguna); ?>" tabindex="-1"
            aria-labelledby="editModalLabel<?php echo e($item->id_pengguna); ?>" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel<?php echo e($item->id_pengguna); ?>">Edit Lapangan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('updatedStatus')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <input type="hidden" name="id_pengguna" value="<?php echo e($item->id_pengguna); ?>">

                            <div class="mb-3">
                                <label for="namaLapangan" class="form-label">Ganti status member</label>
                                <select class="form-select" id="lokasiLapangan" name="id_lokasi">
                                    <option value="1" <?php echo e($item->jenis_pelanggan == 'member' ? 'selected' : ''); ?>>
                                        Member</option>
                                    <option value="2" <?php echo e($item->jenis_pelanggan == 'biasa' ? 'selected' : ''); ?>>Biasa
                                    </option>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    <!-- Add manager Modal -->
    <div class="modal fade" id="addPlayerModal" tabindex="-1" role="dialog" aria-labelledby="addmanagerModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addmanagerModalLabel">Add manager</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('pengguna.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\UAS-PRAK-11423005\resources\views/player/player.blade.php ENDPATH**/ ?>