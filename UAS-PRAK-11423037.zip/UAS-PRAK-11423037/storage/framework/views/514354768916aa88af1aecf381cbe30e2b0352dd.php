

<?php $__env->startSection('title', 'Pengelola Details'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="container">
        <h1>Pengelola List</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Status</th>
                    <th>Mulai</th>
                    <th>Selesai</th>
                    <th>Last Login</th>
                    <th>Lapangan Bekerja</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($manager->id_pengguna); ?></td>
                        <td><?php echo e($manager->username_pengguna); ?></td>
                        <td><?php echo e($manager->pengelola->status); ?></td>
                        <td><?php echo e($manager->pengelola->tanggal_mulai); ?></td>
                        <td><?php echo e($manager->pengelola->tanggal_selesai); ?></td>
                        <td><?php echo e($manager->last_login); ?></td>
                        <td><?php echo e($manager->pengelola->lapangan->nama_lapangan); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <a href="<?php echo e(route('pengelola')); ?>" class="btn btn-primary">Back</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\BookingLapangan\resources\views/manager/manager_show.blade.php ENDPATH**/ ?>