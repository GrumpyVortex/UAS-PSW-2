

<?php $__env->startSection('contents'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Booking Detail</div>

                    <div class="card-body">
                        <div class="mb-3 row">
                            <label for="nama_pemesan" class="col-md-4 col-form-label fw-bold">Nama Pemesan:</label>
                            <div class="col-md-8">
                                <p><?php echo e($booking->nama_pemesan); ?></p>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="email_pemesan" class="col-md-4 col-form-label fw-bold">Email Pemesan:</label>
                            <div class="col-md-8">
                                <p><?php echo e($booking->email_pemesan); ?></p>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="catatan" class="col-md-4 col-form-label fw-bold">Catatan:</label>
                            <div class="col-md-8">
                                <p><?php echo e($booking->catatan); ?></p>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="lapangan" class="col-md-4 col-form-label fw-bold">Nama Lapangan:</label>
                            <div class="col-md-8">
                                <p><?php echo e($booking->lapangan->nama_lapangan); ?></p>
                            </div>
                        </div>                        
                        <div class="mb-3 row">
                            <label for="waktu_mulai" class="col-md-4 col-form-label fw-bold">Waktu Mulai:</label>
                            <div class="col-md-8">
                                <p><?php echo e($booking->waktu_mulai_booking); ?></p>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="waktu_selesai" class="col-md-4 col-form-label fw-bold">Waktu Selesai:</label>
                            <div class="col-md-8">
                                <p><?php echo e($booking->waktu_selesai_booking); ?></p>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="created_by" class="col-md-4 col-form-label fw-bold">Dibuat Oleh:</label>
                            <div class="col-md-8">
                                <p><?php echo e($booking->created_by); ?></p>
                            </div>
                        </div>
                        <button type="button" class="btn btn-secondary"
                            onclick="window.location='<?php echo e(route('booking_list')); ?>'">Back</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\UAS-PRAK-11423005_01\UAS-PRAK-11423005\resources\views/booking/detail_booking.blade.php ENDPATH**/ ?>