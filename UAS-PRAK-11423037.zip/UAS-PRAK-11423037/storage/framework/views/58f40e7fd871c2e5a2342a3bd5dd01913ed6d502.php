

<?php $__env->startSection('title', 'Edit Kategori Lapangan'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">Edit Kategori Lapangan</div>

                        <div class="card-body">

                            <form action="<?php echo e(route('kategori_lapangan.update', $kategori_lapangan->id_katlapangan)); ?>"
                                method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="mb-3">
                                    <label for="nama_katlapangan" class="form-label">Nama Kategori Lapangan</label>
                                    <input type="text" class="form-control" id="nama_katlapangan" name="nama_katlapangan"
                                        value="<?php echo e($kategori_lapangan->nama_katlapangan); ?>">
                                </div>

                                <div class="mb-3">
                                    <label for="harga_katlapangan" class="form-label">Harga Kategori Lapangan</label>
                                    <input type="text" class="form-control" id="harga_katlapangan"
                                        name="harga_katlapangan" value="<?php echo e($kategori_lapangan->harga_katlapangan); ?>">
                                </div>

                                <div class="mb-3">
                                    <label for="file_katlapangan" class="form-label">Deskripsi</label>
                                    <textarea class="form-control" id="file_katlapangan" name="file_katlapangan" rows="3"><?php echo e($kategori_lapangan->file_katlapangan); ?></textarea>
                                </div>

                                <div class="mb-3">
                                    <label for="jumlah_lapangan" class="form-label">Jumlah Lapangan</label>
                                    <input type="number" class="form-control" id="jumlah_lapangan" name="jumlah_lapangan"
                                        value="<?php echo e($kategori_lapangan->jumlah_lapangan); ?>">
                                </div>

                                <input type="hidden" name="updated_by" value="admin">

                                <button type="submit" class="btn btn-primary">Submit</button>
                                <button type="button" class="btn btn-secondary"
                                    onclick="window.location='<?php echo e(route('lapangan_index')); ?>'">Back</button>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\resources\views/court/kategori_lapangan_update.blade.php ENDPATH**/ ?>