

<?php $__env->startSection('title', 'Detail Kategori Lapangan'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Detail Kategori Lapangan</div>

                    <div class="card-body">
                        <div class="mb-3">
                            <label for="nama_katlapangan" class="form-label">Nama Kategori Lapangan</label>
                            <input type="text" class="form-control" id="nama_katlapangan" name="nama_katlapangan"
                                value="<?php echo e($kategori->nama_katlapangan); ?>" readonly>
                        </div>

                        <div class="mb-3">
                            <label for="jenis_lapangan" class="form-label">Jenis Lapangan</label>
                            <input type="text" class="form-control" id="jenis_lapangan" name="jenis_lapangan"
                                value="<?php echo e($kategori->jenis_lapangan); ?>" readonly>
                        </div>

                        <div class="mb-3">
                            <label for="file_katlapangan" class="form-label">Deskripsi</label>
                            <textarea class="form-control" id="file_katlapangan" name="file_katlapangan" rows="3" readonly><?php echo e($kategori->file_katlapangan); ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="created_by" class="form-label">Dibuat Oleh</label>
                            <input type="text" class="form-control" id="created_by" name="created_by"
                                value="<?php echo e($kategori->created_by); ?>" readonly>
                        </div>

                        <div class="mb-3">
                            <label for="created_at" class="form-label">Tanggal Dibuat</label>
                            <input type="text" class="form-control" id="created_at" name="created_at"
                                value="<?php echo e($kategori->created_at); ?>" readonly>
                        </div>

                        <div class="mb-3">
                            <label for="updated_at" class="form-label">Tanggal Diperbarui</label>
                            <input type="text" class="form-control" id="updated_at" name="updated_at"
                                value="<?php echo e($kategori->updated_at); ?>" readonly>
                        </div>

                        <div class="mb-3">
                            <label for="lapangan" class="form-label">Lapangan yang menggunakan kategori ini:</label>
                            <ul>
                                <?php $__currentLoopData = $kategori->lapangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lapangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($lapangan->nama_lapangan); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        
                        <button type="button" class="btn btn-secondary"
                            onclick="window.location='<?php echo e(route('lapangan_index')); ?>'">Back</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\resources\views/court/kategori_lapangan_detail.blade.php ENDPATH**/ ?>