

<?php $__env->startSection('contents'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Tambah Lapangan</div>
                    <div class="card-body">
                        <form action="<?php echo e(route('lapangan.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="nama" class="form-label">Nama Lapangan <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="nama" name="nama_lapangan" placeholder="Nama Lapangan">
                            </div>
                            <div class="mb-3">
                                <label for="harga" class="form-label">Harga Sewa <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="harga" name="harga_lapangan" placeholder="Harga Sewa">
                            </div>
                            <div class="mb-3">
                                <label for="gambar" class="form-label">Gambar Lapangan <span class="text-danger">*</span></label>
                                <input type="file" class="form-control" id="gambar" name="img_lapangan">
                            </div>
                            <div class="mb-3">
                                <label for="deskripsi" class="form-label">Deskripsi <span class="text-danger">*</span></label>
                                <textarea class="form-control" id="deskripsi" name="deskripsi_lapangan" placeholder="Deskripsi Lapangan"></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="lokasi" class="form-label">Lokasi <span class="text-danger">*</span></label>
                                <select class="form-control" id="lokasi" name="id_lokasi">
                                    <option value="">Pilih Lokasi</option>
                                    <?php $__currentLoopData = $data_lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lokasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($lokasi->id_lokasi); ?>"><?php echo e($lokasi->nama_lokasi); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Tambah</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\UAS-PRAK-11423005_01\UAS-PRAK-11423005\resources\views/court/lapangan_create.blade.php ENDPATH**/ ?>