

<?php $__env->startSection('title', 'List Booking'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>List Booking</h2>
                <hr>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Waktu Mulai</th>
                            <th>Waktu Selesai</th>
                            <th>Catatan</th>
                            <th>Lapangan</th>
                            <th>Kategori</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($booking->nama); ?></td>
                                <td><?php echo e($booking->email); ?></td>
                                <td><?php echo e($booking->waktu_mulai); ?></td>
                                <td><?php echo e($booking->waktu_selesai); ?></td>
                                <td><?php echo e($booking->catatan); ?></td>
                                <td><?php echo e($booking->lapangan->nama_lapangan); ?></td>
                                <td><?php echo e($booking->kategori->nama_katlapangan); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\resources\views/booking/list.blade.php ENDPATH**/ ?>