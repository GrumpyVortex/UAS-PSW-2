

<?php $__env->startSection('title', 'Edit Product'); ?>
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Edit Product</h1>
    <hr />
    <form action="<?php echo e(route('update', $product->id_produkolahraga)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nama Produk</label>
                <input type="text" name="nama_produkolahraga" class="form-control" placeholder="Nama Produk"
                    value="<?php echo e(old('nama_produkolahraga', $product->nama_produkolahraga)); ?>">
                <?php $__errorArgs = ['nama_produkolahraga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col mb-3">
                <label class="form-label">Harga</label>
                <input type="text" name="harga_produkolahraga" class="form-control" placeholder="Harga"
                    value="<?php echo e(old('harga_produkolahraga', $product->harga_produkolahraga)); ?>">
                <?php $__errorArgs = ['harga_produkolahraga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Stok</label>
                <input type="text" name="stok_produkolahraga" class="form-control" placeholder="Stok"
                    value="<?php echo e(old('stok_produkolahraga', $product->stok_produkolahraga)); ?>">
                <?php $__errorArgs = ['stok_produkolahraga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col mb-3">
                <label class="form-label">Foto Produk</label>
                <img src="<?php echo e(asset('storage/' . $product->img_product)); ?>" alt="<?php echo e($product->nama_produkolahraga); ?>"
                    style="max-width: 100px;">
                <input type="file" name="img_product" class="form-control">
                <?php $__errorArgs = ['img_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-warning">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\resources\views/product/edit.blade.php ENDPATH**/ ?>