
 
<?php $__env->startSection('title', 'Laravel 10 Login SignUp with User Roles and Permissions with Admin CRUD | Tailwind CSS Custom Login register'); ?>
 
<?php $__env->startSection('contents'); ?>
<div>
    <h1 class="font-bold text-2xl ml-3">Dashboard</h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\resources\views/dashboard_admin.blade.php ENDPATH**/ ?>