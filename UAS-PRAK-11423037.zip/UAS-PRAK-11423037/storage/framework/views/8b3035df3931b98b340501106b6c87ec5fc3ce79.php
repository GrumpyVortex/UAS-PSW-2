


<?php $__env->startSection('title', 'Court List >'); ?>
<?php $__env->startSection('sub_title', 'Booking Form >'); ?>
<?php $__env->startSection('dynamic_nav_links'); ?>

    <li class="nav-item">
        <a class="nav-link" href="#"><?php echo e($lapangan->nama_lapangan); ?></a>
    </li>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <p>Anda akan memesan lapangan
                <h2><?php echo e($lapangan->nama_lapangan); ?></h2>
                <hr>
                <form action="<?php echo e(route('submit_booking')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" value="<?php echo e(session('username')); ?>" id="nama"
                            name="nama">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Alamat Email</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="waktu_mulai" class="form-label">Waktu Mulai</label>
                            <input type="datetime-local" class="form-control" id="waktu_mulai" name="waktu_mulai">
                        </div>
                        <div class="col-md-6">
                            <label for="waktu_selesai" class="form-label">Waktu Selesai</label>
                            <input type="datetime-local" class="form-control" id="waktu_selesai" name="waktu_selesai">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="catatan" class="form-label">Catatan Khusus</label>
                        <textarea class="form-control" id="catatan" name="catatan" rows="3"></textarea>
                    </div>
                    <input type="hidden" name="lapangan_id" value="<?php echo e($lapangan->id_lapangan); ?>">
                    <input type="hidden" name="nama_lapangan" value="<?php echo e($lapangan->nama_lapangan); ?>">
                    <input type="hidden" name="id_pengguna" value="<?php echo e(session('id_pengguna')); ?>">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    <button type="button" class="btn btn-secondary"
                        onclick="window.location='<?php echo e(route('view_lapangan')); ?>'">Back</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\BookingLapangan\resources\views/booking/form.blade.php ENDPATH**/ ?>