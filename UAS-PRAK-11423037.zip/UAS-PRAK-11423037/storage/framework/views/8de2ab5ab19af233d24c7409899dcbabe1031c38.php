

<?php $__env->startSection('title', ' Product Buy'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Form Pembelian Produk</div>

                    <div class="card-body">
                        <h5>Detail Produk</h5>
                        <div class="mb-3">
                            <strong>Nama Produk:</strong> <?php echo e($product->nama_produkolahraga); ?>

                        </div>
                        <div class="mb-3">
                            <strong>Harga:</strong> <?php echo e($product->harga_produkolahraga); ?>

                        </div>
                        <div class="mb-3">
                            <strong>Deskripsi:</strong> <?php echo e($product->deskripsi); ?>

                        </div>

                        <hr>

                        
                        <form action="" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                            <div class="form-group">
                                <label for="quantity">Jumlah Produk</label>
                                <input type="number" name="quantity" id="quantity" class="form-control" value="1" min="1">
                            </div>
                            <button type="submit" class="btn btn-primary">Beli</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\resources\views/product/beli.blade.php ENDPATH**/ ?>