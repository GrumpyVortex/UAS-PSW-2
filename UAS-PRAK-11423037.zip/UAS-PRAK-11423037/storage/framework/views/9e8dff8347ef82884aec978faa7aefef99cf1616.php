

<?php $__env->startSection('title', 'List Purchases'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">List Purchases</div>
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Name of User</th>
                                    <th>Product Name</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total Product</th>
                                    <th>Total Price</th>
                                    <th>Created At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $transaksi_olahraga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($purchase->user->username_pengguna); ?></td>
                                        <td><?php echo e($purchase->product->nama_produkolahraga); ?></td>
                                        <td><?php echo e($purchase->product->harga_produkolahraga ?? '-'); ?></td>
                                        <td><?php echo e($purchase->product->stok_produkolahraga ?? '-'); ?></td>
                                        <td> <?php
                                            $total_produk = 0;
                                            foreach ($transaksi_olahraga as $transaksi) {
                                                $total_produk += $transaksi->jumlah;
                                            }
                                        ?>
                                            <?php echo e($total_produk); ?>

                                        </td>
                                        <td>
                                            <?php
                                                $total_harga = 0;
                                                foreach ($transaksi_olahraga as $transaksi) {
                                                    $total_harga +=
                                                        $transaksi->jumlah * $transaksi->product->harga_produkolahraga;
                                                }
                                            ?>
                                            <?php echo e(number_format($total_harga, 0, ',', '.')); ?>


                                        </td>
                                        <td><?php echo e($purchase->created_at); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('purchase.edit', $purchase->id_transaksi_olahraga)); ?>"
                                                class="btn btn-success">Checkout</a>
                                            <form action="<?php echo e(route('keranjang.hapus', $purchase->id_transaksi_olahraga)); ?>"
                                                method="POST"
                                                onsubmit="return confirm('Apakah Anda yakin ingin menghapus produk dari keranjang belanja?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">Cancel</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\UAS-PRAK-11423005\resources\views/product/purchase.blade.php ENDPATH**/ ?>