

<?php $__env->startSection('title', 'Home Lapangan List'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Lapangan</div>
                    <div class="card-body">
                        <!-- Tabel Lapangan -->
                        <table class="table table-stripped">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Nama Lapangan</th>
                                    <th>Harga Sewa</th>
                                    <th>Jumlah Stok</th>
                                    <th>Gambar</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data_lapangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->nama_lapangan); ?></td>
                                        <td><?php echo e($item->harga_lapangan); ?></td>
                                        <td><?php echo e($item->jumlahLapangan); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset('storage/' . $item->img_lapangan)); ?>" alt="Gambar Lapangan"
                                                width="100">
                                        </td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('update_lapangan', $item->id_lapangan)); ?>"
                                                    class="btn btn-success m-2">EDIT</a>
                                                <a href="<?php echo e(route('detail_lapangan', $item->id_lapangan)); ?>"
                                                    class="btn btn-success m-2">DETAIL</a>
                                                <form action="<?php echo e(route('lapangan.destroy', $item->id_lapangan)); ?>"
                                                    method="POST"
                                                    onsubmit="return confirm('Apakah anda yakin ingin menghapus?')"
                                                    class="float-right text-red-800">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button class="btn btn-danger m-2">Delete</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- Button Add Lapangan -->
                        <button type="button" class="btn btn-primary m-2"
                            onclick="window.location='<?php echo e(route('create_lapangan')); ?>'">ADD</button>
                    </div>
                </div>
                <!-- Tabel Kategori Lapangan -->
                <div class="card mt-5">
                    <div class="card-header">Kategori Lapangan</div>
                    <div class="card-body">
                        <table class="table table-stripped">
                            <thead class="thead-dark">
                                <tr>
                                    <th>id Kategori</th>
                                    <th>Nama Kategori</th>
                                    <th>Deskripsi</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kategori_lapangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($kategori->id_katlapangan); ?></td>
                                        <td><?php echo e($kategori->nama_katlapangan); ?></td>
                                        <td><?php echo e($kategori->file_katlapangan); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('edit_katlapangan', $kategori->id_katlapangan)); ?>" class="btn btn-success m-2">EDIT</a>
                                                <a href="<?php echo e(route('detail_katlapangan', $kategori->id_katlapangan)); ?>" class="btn btn-success m-2">DETAIL</a>
                                                <form action="<?php echo e(route('kategori_lapangan.destroy', $kategori->id_katlapangan)); ?>" method="POST"
                                                    onsubmit="return confirm('Apakah anda yakin ingin menghapus?')"
                                                    class="float-right text-red-800">
                                                  <?php echo csrf_field(); ?>
                                                  <?php echo method_field('DELETE'); ?>
                                                  <button class="btn btn-danger m-2">Delete</button>
                                              </form>
                                              
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <button type="button" class="btn btn-primary m-2"onclick="window.location='<?php echo e(route('create_katlapangan')); ?>'">ADD</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\resources\views/court/lapangan.blade.php ENDPATH**/ ?>