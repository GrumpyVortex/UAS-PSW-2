

<?php $__env->startSection('title', 'Court List'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <?php $__currentLoopData = $data_lapangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lapangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card shadow">
                        <div class="card-body">
                            <img src="<?php echo e(asset('storage/' . $lapangan->img_lapangan)); ?>" class="card-img-top"
                                alt="Lapangan Image">
                            <h5 class="card-title m-3"
                                style="font-family: 'Arial Black', sans-serif; font-size: 2rem; color: #333333;">
                                <?php echo e($lapangan->nama_lapangan); ?></h5>
                            <p class="card-text mb-1"
                                style="font-family: 'Times New Roman', serif; font-size: 1.2rem; color: #666666;">
                                <?php if($lapangan->kategori): ?>
                                    <?php echo e($lapangan->kategori->nama_katlapangan); ?>

                                <?php else: ?>
                                    Kategori lapangan tidak tersedia
                                <?php endif; ?>
                            </p>
                            <p class="card-text mb-1"
                                style="font-family: 'Courier New', monospace; font-size: 1.2rem; color: #666666;">
                                Rp<?php echo e($lapangan->harga_lapangan); ?><b>/Hour</b></p>
                            <p class="card-text mb-1"
                                style="font-family: 'Times New Roman', serif; font-size: 1.2rem; color: #666666;">
                                Type Court:
                                <?php if($lapangan->kategori): ?>
                                    <?php echo e($lapangan->kategori->jenis_lapangan); ?>

                                <?php else: ?>
                                    Jenis lapangan tidak tersedia
                                <?php endif; ?>
                            </p>

                            <?php if(session('is_logged_in')): ?>
                                <a href="<?php echo e(route('user_court_show', $lapangan->id_lapangan)); ?>"
                                    class="btn btn-primary btn-sm">Detail Court</a>
                                <a href="<?php echo e(route('book_now', ['id_lapangan' => $lapangan->id_lapangan])); ?>"
                                    class="btn btn-success btn-sm">Book Now</a>
                            <?php else: ?>
                                <a href="<?php echo e(route('user_court_show', $lapangan->id_lapangan)); ?>"
                                    class="btn btn-primary btn-sm">Detail Court</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\UAS-PRAK-11423005_01\UAS-PRAK-11423005\resources\views/court/lapangan_user.blade.php ENDPATH**/ ?>