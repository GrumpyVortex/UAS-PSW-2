

<?php $__env->startSection('title', 'Member Details'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="container">
        <h1>Member Details</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Last Login</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo e($member->id_pengguna); ?></td>
                    <td><?php echo e($member->username_pengguna); ?></td>
                    <td><?php echo e($member->email_pengguna); ?></td>
                    <td><?php echo e($member->last_login); ?></td>
                </tr>
            </tbody>
        </table>
        <a href="<?php echo e(route('member')); ?>" class="btn btn-primary">Back</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\BookingLapangan\resources\views/member/member_show.blade.php ENDPATH**/ ?>