

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Status Keanggotaan</div>

                <div class="card-body">
                    <?php if($pelanggan && $pelanggan->jenis_pelanggan == 'member'): ?>
                        <div class="alert alert-success" role="alert">
                            Selamat! Anda adalah member hingga <?php echo e($pelanggan->tgl_berakhir_member->format('d F Y')); ?>

                        </div>
                        <a style="text-decoration: none;" href="<?php echo e(route('membership.beli', ['id_pengguna' => $idPengguna])); ?>">Perpanjang waktu membership</a>
                    <?php else: ?>
                        <div class="alert alert-warning" role="alert">
                            Anda belum menjadi member. <a href="<?php echo e(route('membership.beli', ['id_pengguna' => $idPengguna])); ?>">Daftar sekarang!</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\UAS-PRAK-11423005_01\UAS-PRAK-11423005\resources\views/membership/status.blade.php ENDPATH**/ ?>