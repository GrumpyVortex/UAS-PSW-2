

<?php $__env->startSection('title', 'Product List'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <?php $__currentLoopData = $data_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card shadow">
                        <div class="card-body">
                            <img src="<?php echo e(asset('storage/' . $item->img_product)); ?>" class="card-img-top" alt="Product Image">
                            <h4 class="card-title m-3" style="font-family: 'Arial Black', sans-serif; font-size: 2rem;">
                                <?php echo e($item->nama_produkolahraga); ?></h4>
                            <p class="card-text mb-1" style="font-family: 'Courier New', monospace; font-size: 1.2rem;">
                                Rp<?php echo e($item->harga_produkolahraga); ?><b>/Item</b></p>
                            <p class="card-text mb-1" style="font-family: 'Times New Roman', serif; font-size: 1.2rem;">
                                Stok: <?php echo e($item->stok_produkolahraga); ?></p>
                            <?php if(session('is_logged_in')): ?>
                                <a href="<?php echo e(route('product_show', $item->id_produkolahraga)); ?>"
                                    class="btn btn-primary btn-sm">Detail Produk</a>
                                <a class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#beliModal"
                                    data-idUpdate="'.$item->id_produkolahraga.'" data-target="#UserUpdate">
                                    Beli
                                </a>
                            <?php else: ?>
                                <a href="<?php echo e(route('product_show', $item->id_produkolahraga)); ?>"
                                    class="btn btn-primary btn-sm">Detail Produk</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


    

    <div class="modal fade" id="beliModal" tabindex="-1" aria-labelledby="beliModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="beliModalLabel">Beli Produk</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h5>Detail Produk</h5>
                    <div class="mb-3">
                        <strong>Nama Produk:</strong> <?php echo e($item->nama_produkolahraga); ?>

                    </div>
                    <div class="mb-3">
                        <strong>Harga:</strong> <?php echo e($item->harga_produkolahraga); ?>

                    </div>
                    <div class="mb-3">
                        <strong>Deskripsi:</strong> <?php echo e($item->deskripsi); ?>

                    </div>
                    <!-- Form pembelian produk -->
                    <form action="<?php echo e(route('beli.product', $item->id_produkolahraga)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <!-- Isi form pembelian disini -->
                        <!-- Contoh: -->
                        <div class="mb-3">
                            <label for="nama">Nama:</label>
                            <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e(session('username')); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="jumlah">Jumlah:</label>
                            <input type="number" class="form-control" id="jumlah" name="jumlah">
                        </div>
                        <input type="hidden" name="product_id" value="<?php echo e($item->id_produkolahraga); ?>">
                        <button type="submit" class="btn btn-success">Beli</button>
                    </form>

                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\UAS-PRAK-11423005_01\UAS-PRAK-11423005\resources\views/product/product_user.blade.php ENDPATH**/ ?>