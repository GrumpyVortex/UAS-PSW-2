

<?php $__env->startSection('title', 'Edit Lapangan'); ?>
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Edit Lapangan</h1>
    <hr />
    <form action="<?php echo e(route('lapangan.update', $lapangan->id_lapangan)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nama Lapangan</label>
                <input type="text" name="nama_lapangan" class="form-control" placeholder="Nama Lapangan"
                    value="<?php echo e(old('nama_lapangan', $lapangan->nama_lapangan)); ?>">
                <?php $__errorArgs = ['nama_lapangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col mb-3">
                <label class="form-label">Harga</label>
                <input type="text" name="harga_lapangan" class="form-control" placeholder="Harga"
                    value="<?php echo e(old('harga_lapangan', $lapangan->harga_lapangan)); ?>">
                <?php $__errorArgs = ['harga_lapangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Deskripsi Lapangan</label>
                <textarea name="deskripsi_lapangan" class="form-control" placeholder="Deskripsi Lapangan"><?php echo e(old('deskripsi', $lapangan->deskripsi_lapangan)); ?></textarea>
                <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col mb-3">
                <label class="form-label">Gambar Lapangan</label>
                <img src="<?php echo e(asset('storage/' . $lapangan->img_lapangan)); ?>" class="img-fluid" width="100" alt="Gambar Lapangan">
                <input type="file" name="img_lapangan" class="form-control">
                <?php $__errorArgs = ['img_lapangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="row">
            <div class="d-grid">
                <button class="btn btn-warning">Update</button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan\BookingLapangan\resources\views/court/lapangan_edit.blade.php ENDPATH**/ ?>